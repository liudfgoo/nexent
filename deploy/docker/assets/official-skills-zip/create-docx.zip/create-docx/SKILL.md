---
name: create-docx
description: Create and generate Word documents (.docx) from structured specifications. Use when the user wants to create a Word document from scratch, generate a report, refine an existing document, or perform focused edits such as replacing text, adding images, or adjusting layout. Supports one-shot generation and fine-grained document editing.
script_outputs:
  scripts/generate_docx.py:
    kind: file
    mime_types:
      - application/vnd.openxmlformats-officedocument.wordprocessingml.document
  scripts/get_document_path.py:
    kind: file
    mime_types:
      - application/vnd.openxmlformats-officedocument.wordprocessingml.document
---

# Word Document Skill

This skill supports two workflows:

1. One-shot generation of a complete Word document from structured input.
2. Fine-grained editing of an existing Word document through small, focused scripts.

## Workflow Selection

### Use `generate_docx.py` when
- The user wants to create a complete document from scratch.
- The content is already organized as sections, paragraphs, and tables.
- You should not simulate document assembly with multiple incremental edits.

### Use the editing scripts when
- The user wants to modify an existing document.
- The user wants to change a specific heading, paragraph, table cell, or image.
- The user wants to adjust page layout, headers, or footers.

## Core Principle

- `generate_docx.py` is the preferred entry point for full document creation.
- `create_document.py` creates an empty document only.
- `add_*` scripts perform one focused edit at a time.
- `replace_*` and `rename_*` scripts are used for modifications, not additions.

## Quick Usage

```python
import json

spec = {
    "title": "Document Title",
    "sections": [
        {
            "heading": "Section 1",
            "heading_level": 2,
            "paragraphs": [
                {"text": "Introduction paragraph here."},
                {"text": "Bold text", "bold": true}
            ],
            "tables": [
                {
                    "data": [["Name", "Value"], ["Item1", "100"]],
                    "has_header": true
                }
            ]
        }
    ]
}

result = run_skill_script(
    "create-docx",
    "scripts/generate_docx.py",
    params=f'--spec \'{json.dumps(spec, ensure_ascii=False)}\' --output "report.docx"'
)

return result
```

## Return Format

Return the raw JSON result from the invoked script directly. Do not reformat or summarize it as markdown.

```json
{
    "status": "success",
    "artifacts": [
        {
            "kind": "file",
            "absolute_path": abs_path,
            "file_name": os.path.basename(abs_path),
            "mime_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "file_size_bytes": file_size,
        }
    ],
    "message": "Document created successfully."
}

```

## Parameter Naming

Always use `params` as the third argument.

```python
run_skill_script("create-docx", "scripts/generate_docx.py", params="--arg value")
```

## Script Selection Guide

### Create and generate
- `generate_docx.py` — generate a complete document from JSON spec
- `create_document.py` — create a blank document shell

### Add content
- `add_heading.py` — add a new heading
- `add_paragraph.py` — add a new paragraph
- `add_table.py` — add a new table
- `add_image.py` — add an image

### Modify existing content
- `replace_text.py` — replace matching text in the document
- `rename_heading.py` — rename an existing heading
- `update_table_cell.py` — change a specific table cell

### Layout and structure
- `set_page_margins.py` — adjust page margins
- `set_page_orientation.py` — switch between portrait and landscape
- `set_page_size.py` — change paper size
- `add_header.py` — add or update the header
- `add_footer.py` — add or update the footer
- `get_document_info.py` — inspect document structure before editing
- `get_document_path.py` — prepare a document for upload or preview

## Current Scripts

### `generate_docx.py`
Generate a complete Word document from a structured specification in one execution.

Use this for full document creation. Do not split a single document generation task into multiple script calls.

### `create_document.py`
Create a new blank document.

Use this when the user only needs an empty document file as a starting point.

### `add_paragraph.py`
Add a paragraph to an existing document.

Use this for appending or inserting new body text.

### `add_heading.py`
Add a heading to an existing document.

Use this for adding a new heading. Do not use it to rename an existing heading.

### `add_table.py`
Add a table to an existing document.

Use this for inserting a new table at the current document position.

### `get_document_path.py`
Get the path and metadata of a Word document.

Use this before returning a generated file to the backend or preview layer.

## File Artifact Contract

Only scripts declared in the `script_outputs` frontmatter map may return downloadable file artifacts. In this skill, those scripts are:

- `scripts/generate_docx.py`
- `scripts/get_document_path.py`

A successful file-producing script must return this shape:

```json
{
  "status": "success",
  "artifacts": [
    {
      "kind": "file",
      "absolute_path": "/mnt/nexent/report.docx",
      "file_name": "report.docx",
      "mime_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "file_size_bytes": 12800
    }
  ]
}
```

Editing scripts modify the working document but do not publish an attachment. Call `get_document_path.py` after the final edit to publish the finished document.

## Recommended Additional Scripts

The following scripts are recommended to improve fine-grained document editing:

- `replace_text.py`
- `rename_heading.py`
- `add_image.py`
- `update_table_cell.py`
- `set_page_margins.py`
- `set_page_orientation.py`
- `set_page_size.py`
- `add_header.py`
- `add_footer.py`
- `get_document_info.py`

## Usage Rules

- Use `generate_docx.py` for first-pass document creation.
- Use editing scripts for user revisions after generation.
- If the user requests changing an existing heading name, use `rename_heading.py` or `replace_text.py` rather than `add_heading.py`.
- If the user wants precise edits, inspect the document with `get_document_info.py` first when necessary.
- Keep each script focused on one action.
- Avoid chaining many scripts to imitate full document generation.

## Specification Schema

| Field | Type | Description |
|-------|------|-------------|
| `title` | string | Document title as a level 1 heading |
| `sections` | array | List of sections |
| `sections[].heading` | string | Section heading text |
| `sections[].heading_level` | int | Heading level 1-9, default 2 |
| `sections[].paragraphs` | array | List of paragraphs |
| `sections[].paragraphs[].text` | string | Paragraph text |
| `sections[].paragraphs[].style` | string | Optional paragraph style |
| `sections[].paragraphs[].bold` | bool | Bold text, default false |
| `sections[].paragraphs[].italic` | bool | Italic text, default false |
| `sections[].tables` | array | List of tables |
| `sections[].tables[].data` | array | 2D array of cell values |
| `sections[].tables[].has_header` | bool | First row is header, default true |

## Document Structure Example

```
Title: Document Title

## Section 1: Introduction
This is the introduction paragraph.

## Section 2: Data
Table with columns [Name, Value]:
Name1, 100
Name2, 200

## Section 3: Conclusion
Final paragraph.
```

The agent should convert the structure above into a JSON specification for `generate_docx.py`.

## Output Format

All scripts return JSON. Return the raw result directly. Only `script_outputs` entries that return an `artifacts` array are uploaded as downloadable attachments.

## Storage

- Default directory: `/mnt/nexent`
- Custom directory: use `--working-dir`
- The backend uploads generated files to S3 and removes local files after generation when appropriate.
