#!/usr/bin/env python3
"""Add a paragraph to a Word document."""

import argparse
import json
import os
import sys


# Default directory for generated files (same as other file creation tools)
DEFAULT_OUTPUT_DIR = "/mnt/nexent"


def add_paragraph(
    path: str,
    text: str,
    style: str = None,
    bold: bool = False,
    italic: bool = False,
    working_dir: str = None
) -> dict:
    """Add a paragraph to an existing Word document."""
    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    from docx import Document

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Document not found: {abs_path}")

    doc = Document(abs_path)

    # Add paragraph
    if style:
        paragraph = doc.add_paragraph(text, style=style)
    else:
        paragraph = doc.add_paragraph(text)

    # Apply formatting
    if bold or italic:
        for run in paragraph.runs:
            run.bold = bold
            run.italic = italic

    doc.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "paragraph_length": len(text)
    }


def main():
    parser = argparse.ArgumentParser(description="Add a paragraph to a Word document")
    parser.add_argument("--path", "-p", required=True, help="Document path")
    parser.add_argument("--text", "-t", required=True, help="Paragraph text")
    parser.add_argument("--style", "-s", default=None, help="Paragraph style")
    parser.add_argument("--bold", "-b", action="store_true", help="Make text bold")
    parser.add_argument("--italic", "-i", action="store_true", help="Make text italic")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = add_paragraph(
            args.path,
            args.text,
            style=args.style,
            bold=args.bold,
            italic=args.italic,
            working_dir=args.working_dir
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
