#!/usr/bin/env python3
"""Add an image to a Word document."""

import argparse
import json
import os
import sys


DEFAULT_OUTPUT_DIR = "/mnt/nexent"


def add_image(path: str, image_path: str, width: float = None, height: float = None, working_dir: str = None) -> dict:
    """Add an image to an existing Word document."""
    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    from docx import Document
    from docx.shared import Inches

    abs_path = os.path.abspath(os.path.join(working_dir, path))
    abs_image_path = os.path.abspath(os.path.join(working_dir, image_path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Document not found: {abs_path}")
    if not os.path.exists(abs_image_path):
        raise FileNotFoundError(f"Image not found: {abs_image_path}")

    doc = Document(abs_path)
    paragraph = doc.add_paragraph()
    run = paragraph.add_run()

    if width is not None and height is not None:
        run.add_picture(abs_image_path, width=Inches(width), height=Inches(height))
    elif width is not None:
        run.add_picture(abs_image_path, width=Inches(width))
    elif height is not None:
        run.add_picture(abs_image_path, height=Inches(height))
    else:
        run.add_picture(abs_image_path)

    doc.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "image_path": image_path
    }


def main():
    parser = argparse.ArgumentParser(description="Add an image to a Word document")
    parser.add_argument("--path", "-p", required=True, help="Document path")
    parser.add_argument("--image-path", required=True, help="Image path")
    parser.add_argument("--width", type=float, default=None, help="Image width in inches")
    parser.add_argument("--height", type=float, default=None, help="Image height in inches")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = add_image(args.path, args.image_path, args.width, args.height, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
